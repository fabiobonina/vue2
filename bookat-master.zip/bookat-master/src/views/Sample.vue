<template>
  <div>
    ...
  </div>
</template>

<style scoped>
</style>

<script>
export default {

  name: 'Sample',

  data() {
    return {
    };
  },

};
</script>
