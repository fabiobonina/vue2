<template>
  <div class="-x-view">

  </div>
</template>

<script>
export default {

  name: 'ServiceIndex',

  data() {
    return {
    };
  },

};
</script>

<style scoped>
</style>
