<template>
  <div>
    ...
  </div>
</template>

<script>
export default {

  name: 'Sample',

  data() {
    return {
    };
  },

};
</script>

<style scoped>

</style>
