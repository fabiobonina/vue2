<template>
  <div>
    ...
  </div>
</template>

<script>
export default {

  name: 'ServiceItem',

  data() {
    return {
    };
  },

};
</script>

<style scoped>

</style>
