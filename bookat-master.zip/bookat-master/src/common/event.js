
import Vue from 'vue';

const EVENT = new Vue();

export default EVENT;
