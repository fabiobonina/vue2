
import Vue from 'vue';

Vue.component('x-snackbar', require('@/components/XSnackbar').default);
